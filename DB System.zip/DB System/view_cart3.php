<?php
  ob_start();
  session_start();
  require_once 'dbconnect.php';
  
  // if session is not set this will redirect to login page
  if( !isset($_SESSION['user']) ) {
    header("Location: index.php");
    exit;
  }
  // select loggedin users detail
  $res=mysql_query("SELECT * FROM users WHERE userId=".$_SESSION['user']);
  $userRow=mysql_fetch_array($res);
?>
<?php
session_start();
include_once("config.php");


//current URL of the Page. cart_update.php redirects back to this URL
$current_url = urlencode($url="http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']);
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Employee List | Admin's Page</title>
<link rel="stylesheet" href="assets/css/bootstrap.min.css" type="text/css"  />
<link rel="stylesheet" href="style.css" type="text/css" />
</head>
<script>
function myFunction() {
    window.print();
}
</script>
<body>

  <nav class="navbar navbar-default navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="emplist.php">Admin's Page</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
            <!--<li><a href="home.php">Home</a></li>-->

            <!--<li><a href="service.php">Service Package</a></li>-->
            <li class="active"><a href="emplist.php">Employee List</a></li>
            <li><a href="order.php">Manage Order <span class="badge" style="background-color: red;">5</span></a></li>
            <li><a href="service.php">Service Package</a></li>
            <li><a href="view3.php">Order</a></li>
            <li><a href="about.php">About</a></li>
          </ul>
          <ul class="nav navbar-nav navbar-right">
            <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="" data-toggle="dropdown">Message</span><span class="badge" style="background-color: red;">3</span></a>
            <div class="dropdown-menu" aria-labelledby="dropdown01" style="width: 250px;">
              <h5><center>Message</h5>
              <p>&nbsp;Customer's say # 1: </p>
              <p>&nbsp;Customer's say # 2: </p>
              <p>&nbsp;Customer's say # 3: </p>
            </div>
          </li>
            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
        <span class="glyphicon glyphicon-user"></span>&nbsp;Hi' <?php echo $userRow['userEmail']; ?>&nbsp;<span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="logout.php?logout"><span class="glyphicon glyphicon-log-out"></span>&nbsp;Sign Out</a></li>
              </ul>
            </li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav> 

  <div id="wrapper">
   <div id="wrapper">

    <div class="container">
   <br>
    <?php
include_once 'dbconnect.php';
?>
<div class="clearfix"></div>

<div class="container">
<div class="page-header">
    <h2>
      <i class="glyphicon glyphicon-align-left"></i> 
      Menu Course - View 
      
    </h2>
  </div>
<div class="cart-view-table-back">
<form method="post" action="cart_update.php">
<table width="100%"  cellpadding="6" cellspacing="0"><thead><tr><th>Quantity</th><th>Name</th><th>Price</th><th>Total</th><th>Remove</th></tr></thead>
  <tbody>
  <?php
  if(isset($_SESSION["cart_products"])) //check session var
    {
    $total = 0; //set initial total value
    $b = 0; //var for zebra stripe table 
    foreach ($_SESSION["cart_products"] as $cart_itm)
        {
      //set variables to use in content below
      $product_name = $cart_itm["product_name"];
      $product_qty = $cart_itm["product_qty"];
      $product_price = $cart_itm["product_price"];
      $product_code = $cart_itm["product_code"];
      //$product_color = $cart_itm["product_color"];
      $subtotal = ($product_price * $product_qty); //calculate Price x Qty
      
        $bg_color = ($b++%2==1) ? 'odd' : 'even'; //class for zebra stripe 
        echo '<tr class="'.$bg_color.'">';
      echo '<td><input type="text" size="2" maxlength="2" name="product_qty['.$product_code.']" value="'.$product_qty.'" /></td>';
      echo '<td>'.$product_name.'</td>';
      echo '<td> Php '.$product_price.'</td>';
      echo '<td> Php '.$subtotal.'</td>';
      echo '<td><input type="checkbox" name="remove_code[]" value="'.$product_code.'" /></td>';
            echo '</tr>';
      $total = ($total + $subtotal); //add subtotal to total var
        }
    
    $grand_total = $total + $shipping_cost; //grand total including shipping cost
    foreach($taxes as $key => $value){ //list and calculate all taxes in array
        $tax_amount     = round($total * ($value / 100));
        $tax_item[$key] = $tax_amount;
        $grand_total    = $grand_total + $tax_amount;  //add tax val to grand total
    }
    
    $list_tax       = '';
    foreach($tax_item as $key => $value){ //List all taxes
      $list_tax .= $key. ' : '. $currency. sprintf("%01.2f", $value).'<br />';
    }
    $shipping_cost = ($shipping_cost)?'Shipping Cost : '.$currency. sprintf("%01.2f", $shipping_cost).'<br />':'';
  }
    ?>
    <tr><td colspan="5"><span style="float:right;text-align: right;"><!--<?php echo $shipping_cost. $list_tax; ?>-->Amount Payable : <?php echo sprintf("%01.2f", $grand_total);?></span></td></tr>
    <tr><td colspan="5"><a href="ord1.php" class="button" style="text-decoration: none;">Add More Course</a><button type="submit">Update</button></td></tr>
  </tbody>
</table>
<input type="hidden" name="return_url" value="<?php 
$current_url = urlencode($url="http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']);
echo $current_url; ?>" />
</form>
</div>


        
       
</div>
      <hr>
      <footer>
        <p>&copy; Copyright All Right Reserved 2017 | Admin's Page</p>
      </footer><br>
    </div>
    
    </div>
    
    <script src="assets/jquery-1.11.3-jquery.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    
</body>
</html>
<?php ob_end_flush(); ?>