<?php
  ob_start();
  session_start();
  require_once 'dbconnect.php';
  
  // if session is not set this will redirect to login page
  if( !isset($_SESSION['user']) ) {
    header("Location: index.php");
    exit;
  }
  // select loggedin users detail
  $res=mysql_query("SELECT * FROM users WHERE userId=".$_SESSION['user']);
  $userRow=mysql_fetch_array($res);
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Manage Order - Edit | Admin's Page</title>
<script src="js/angular.min.js"></script>
<link rel="stylesheet" href="assets/css/bootstrap.min.css" type="text/css"  />
<link rel="stylesheet" href="style.css" type="text/css" />
</head>
<body>

  <nav class="navbar navbar-default navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="emplist.php">Admin's Page</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
            <li><a href="emplist.php">Employee List</a></li>
            <li class="active"><a href="order.php">Manage Order <span class="badge" style="background-color: red;">5</span></a></li>
            <li><a href="service.php">Service Package</a></li>
            <li><a href="about.php">About</a></li>
          </ul>
          <ul class="nav navbar-nav navbar-right">
            <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="" data-toggle="dropdown">Messege</span><span class="badge" style="background-color: red;">3</span></a>
            <div class="dropdown-menu" aria-labelledby="dropdown01" style="width: 250px;">
              <h5><center>Message</h5>
              <p>&nbsp;Customer's say # 1: </p>
              <p>&nbsp;Customer's say # 2: </p>
              <p>&nbsp;Customer's say # 3: </p>
            </div>
          </li>
            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
        <span class="glyphicon glyphicon-user"></span>&nbsp;Hi' <?php echo $userRow['userEmail']; ?>&nbsp;<span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="logout.php?logout"><span class="glyphicon glyphicon-log-out"></span>&nbsp;Sign Out</a></li>
              </ul>
            </li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav> 

  <div id="wrapper">

  <div class="container">
   <br>
    <?php
include_once 'dbconnect.php';
if(isset($_POST['btn-update']))
{
  $id = $_GET['edit_id'];
  $cname = $_POST['cust_name'];
  $course = $_POST['course'];
  $qty = $_POST['quantity'];
  $price = $_POST['price'];
  $total = $_POST['total'];
  $cash = $_POST['cash'];
  $chnge = $_POST['chnge'];
  
  if($order->update($id,$cname,$course,$qty,$price,$total,$cash,$chnge))
  {
    $msg = "<div class='alert alert-info'>
        <strong>Manage Order</strong> was updated successfully!
        </div>";
  }
  else
  {
    $msg = "<div class='alert alert-warning'>
        <strong>SORRY!</strong> ERROR while updating manage order !
        </div>";
  }
}

if(isset($_GET['edit_id']))
{
  $id = $_GET['edit_id'];
  extract($order->getID($id)); 
}

?>
<div class="clearfix"></div>

<div class="container">
<?php
if(isset($msg))
{
  echo $msg;
}
?>
</div>

<div class="clearfix"></div>

<div class="container">
       <div class="page-header">
      <h2>
      <i class="glyphicon glyphicon-align-left"></i> 
      Manage Order - Edit
      </h2>
    </div>

     <form method='post'>
 
    <table class='table table-bordered' data-ng-app="" data-ng-init="quantity=0;price=0;cash=0;chnge=0" >
 
        <tr>
            <td>Customer Name</td>
            <td><input type='text' name='cust_name' class='form-control' value="<?php echo $cust_name; ?>" required></td>
        </tr>
        
        <tr>
            <td>Course</td>
            <td><input type='text' name='course' class='form-control' value="<?php echo $course; ?>" required></td>
        </tr>
 
        <tr>
            <td>Quantity</td>
            <td><input type='' name='quantity'  class='form-control' ng-model="quantity" value="" required></td>
        </tr>
 
        <tr>
            <td>Price</td>
            <td><input type='' name='price' class='form-control' ng-model="price" value="" required></td>
        </tr>
        <tr>
            <td>Total</td>
            <td><input type='' name='total' class='form-control'  value="{{quantity*price}}" ></td>
        </tr>
        <tr>
            <td>Cash</td>
            <td><input type='' name='cash' class='form-control' ng-model="cash" ></td>
        </tr>
        <tr>
            <td>Change</td>
            <td><input type='' name='chnge' class='form-control' value="{{cash-(quantity*price)}}"></td>
        </tr>
        <tr>
            <td colspan="2">
                <button type="submit" class="btn" name="btn-update">
          <span class="glyphicon glyphicon-edit"></span>  Update this Manage Order
        </button>
                <a href="order.php" class="btn btn-large btn-success"><i class="glyphicon glyphicon-backward"></i> &nbsp; CANCEL</a>
            </td>
        </tr>
 
    </table>
</form>
     
     
</div>
     <hr>
      <footer>
        <p>&copy; Copyright All Right Reserved 2017 | Admin's Page</p>
      </footer><br>
    </div>
    
    </div>
    
    <script src="assets/jquery-1.11.3-jquery.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    
</body>
</html>
<?php ob_end_flush(); ?>