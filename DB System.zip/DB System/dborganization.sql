-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 11, 2017 at 02:50 PM
-- Server version: 10.1.16-MariaDB
-- PHP Version: 5.6.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dborganization`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_emp`
--

CREATE TABLE `tbl_emp` (
  `id` int(11) NOT NULL,
  `first_name` varchar(25) NOT NULL,
  `last_name` varchar(25) NOT NULL,
  `address` varchar(50) NOT NULL,
  `status` varchar(10) NOT NULL,
  `position` varchar(30) NOT NULL,
  `dates` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_emp`
--

INSERT INTO `tbl_emp` (`id`, `first_name`, `last_name`, `address`, `status`, `position`, `dates`) VALUES
(1, 'James', 'Arthur', 'Mabolo City', 'Active', 'Deliver Boy', '2015-11-18'),
(2, 'Maria', 'Dela Cruz', 'Brgy. Toong City', 'In-Active', 'Cashier', '2015-03-31'),
(3, 'Domenic', 'Batad', 'Bantayan City', 'In-Active', 'Waiter', '2001-08-14'),
(4, 'Juan', 'Cruz', 'Pardo Cebu City', 'Active', 'Deliver Boy', '2014-12-21'),
(5, 'Lyca', 'McDonald', 'Saciangko Cebu City', 'Active', 'Cook''s Chef', '2012-02-13'),
(6, 'Ryan', 'Gemira', 'Tanjay Negros Oriental City ', 'In-Active', 'Waiter', '2016-09-07'),
(7, 'Anthony', 'Silva', 'Legaspi St. City', 'Active', 'Cashier', '2013-12-05'),
(8, 'Victor', 'Pusta', 'Bohol City', 'In-Active', 'Deliver Boy', '2009-01-19'),
(9, 'Kev', 'Batad', 'Pasil Cebu City', 'Active', 'Waiter', '2015-03-04'),
(10, 'Johl', 'Navarro', 'Pasig City', 'In-Active', 'Cashier', '2916-08-13'),
(13, 'Romeo', 'Zabate', 'Danao', 'In-Active', 'Waiter', '2017-12-31');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order`
--

CREATE TABLE `tbl_order` (
  `id` int(11) NOT NULL,
  `cust_name` varchar(25) NOT NULL,
  `course` varchar(25) NOT NULL,
  `quantity` varchar(50) NOT NULL,
  `price` bigint(10) NOT NULL,
  `total` bigint(100) NOT NULL,
  `cash` bigint(255) NOT NULL,
  `chnge` bigint(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_order`
--

INSERT INTO `tbl_order` (`id`, `cust_name`, `course`, `quantity`, `price`, `total`, `cash`, `chnge`) VALUES
(1, 'Hannah', 'Seafood [Tinola (Classic ', '2', 70, 140, 150, 10),
(2, 'James', 'BBQ [Paa - Php 45.00]', '3', 45, 135, 150, 15),
(3, 'Gloria', 'Seafood [Camaron Rebosado', '1', 80, 80, 80, 0),
(4, 'Mac-Mac', 'Sizzling [Sizzling Pork S', '2', 90, 180, 200, 20),
(5, 'Bryan', 'Seafood [Calamaris - Php ', '2', 70, 140, 280, 140),
(6, 'Arthur', 'BBQ [Isaw - Php 5.00]', '5', 5, 25, 30, 5),
(7, 'Shaina', 'Seafood [Tinola (Classic ', '1', 70, 70, 80, 10),
(8, 'Junelie', 'BBQ [Pork BBQ - Php 6.00]', '20', 6, 120, 500, 380),
(9, 'Gelli', 'Seafood [Linarang Sinigan', '5', 70, 350, 1000, 650),
(10, 'Jeniesl', 'Seafood [Sinigang Shrimp ', '5', 80, 400, 1000, 600),
(11, 'Glendford', 'BBQ [Liver - Php 15.00]', '2', 15, 30, 50, 20),
(12, 'Carlo', 'Seafood [Tinola (Classic ', '2', 70, 140, 150, 10),
(13, 'Angelika', 'Seafood [Gambas - Php 80.', '10', 80, 800, 1000, 200),
(14, 'Duane', 'Seafood [Camaron Rebosado', '2', 80, 160, 500, 340),
(16, 'Jezreel', 'Seafood [Sinigang Shrimp ', '2', 80, 160, 200, 40),
(17, 'Ritche', 'Seafood [Calamaris - Php ', '3', 70, 210, 500, 290),
(19, 'Romeo', 'Seafood [Calamaris - Php ', '2', 70, 140, 500, 360),
(20, 'Arjea', 'BBQ [Skinless - Php 15.00', '3', 15, 45, 50, 5),
(21, 'Flores', 'Seafood [Calamaris - Php ', '2', 70, 140, 200, 60),
(22, 'Juan', 'BBQ [Isaw - Php 5.00]', '5', 5, 25, 50, 25),
(23, 'Sheryl', 'Seafood [Tinola (Classic ', '2', 70, 140, 200, 60),
(24, 'Juan', 'Seafood [Sinigang Shrimp ', '2', 80, 160, 500, 340);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_service`
--

CREATE TABLE `tbl_service` (
  `id` int(11) NOT NULL,
  `price` varchar(25) NOT NULL,
  `description` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_service`
--

INSERT INTO `tbl_service` (`id`, `price`, `description`) VALUES
(1, '9,800', '4 main course + 1 Dessert + One-Round Drinks or Healthy Fruits Infusion + Unlimited Rice + Fruits in Season + 1 kind of Soup of your choice'),
(2, '80000', 'yjga');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `userId` int(11) NOT NULL,
  `userName` varchar(30) NOT NULL,
  `userEmail` varchar(60) NOT NULL,
  `userPass` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userId`, `userName`, `userEmail`, `userPass`) VALUES
(9, 'admin', 'admin@yahoo.com', '240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa822809f74c720a9'),
(15, 'customerA', 'customer1@yahoo.com', 'b041c0aeb35bb0fa4aa668ca5a920b590196fdaf9a00eb852c9b7f4d123cc6d6');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_emp`
--
ALTER TABLE `tbl_emp`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_order`
--
ALTER TABLE `tbl_order`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_service`
--
ALTER TABLE `tbl_service`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userId`),
  ADD UNIQUE KEY `userEmail` (`userEmail`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_emp`
--
ALTER TABLE `tbl_emp`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `tbl_order`
--
ALTER TABLE `tbl_order`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
--
-- AUTO_INCREMENT for table `tbl_service`
--
ALTER TABLE `tbl_service`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `userId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
