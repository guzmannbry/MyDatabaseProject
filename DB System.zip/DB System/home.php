<?php
	ob_start();
	session_start();
	require_once 'dbconnect.php';
	
	// if session is not set this will redirect to login page
	if( !isset($_SESSION['user']) ) {
		header("Location: index.php");
		exit;
	}
	// select loggedin users detail
	$res=mysql_query("SELECT * FROM users WHERE userId=".$_SESSION['user']);
	$userRow=mysql_fetch_array($res);
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Home | Grill House </title>
<link rel="stylesheet" href="assets/css/bootstrap.min.css" type="text/css"  />
<link rel="stylesheet" href="style.css" type="text/css" />
</head>
<body>

	<nav class="navbar navbar-default navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="home.php">Grill House</a>
        </div>
        
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
            <li class="active"><a href="home.php">Home</a></li>
            <li><a href="service1.php">Service Package</a></li>
            <li><a href="order1.php">Manage Order</a></li>
            <li><a href="about1.php">About</a></li>
          <li><a href="contact1.php">Contact</a></li>
          </ul>

          <ul class="nav navbar-nav navbar-right">
          		<li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="" data-toggle="dropdown">Message</span><span class="badge" style="background-color: red;">1</span></a>
            <div class="dropdown-menu" aria-labelledby="dropdown01" style="width: 250px;">
              <h5><center>Message</h5>
              <p><center>2 Message From Admin 1 </p>
            </div>
          </li>
        
            <li class="dropdown">

              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
			  <span class="glyphicon glyphicon-user"></span>&nbsp;Hi' <?php echo $userRow['userEmail']; ?>&nbsp;<span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="logout.php?logout"><span class="glyphicon glyphicon-log-out"></span>&nbsp;Sign Out</a></li>
              </ul>
            </li>
          </ul>
        </div><!--/.nav-collapse -->

      </div>
    </nav> 

	<div id="wrapper">

	
<div class="container" >

<div class="page-header" >

   <h1>
    <center> 
        <img src="img/logo.png" style="width: 20%;">
        </center>
    </h1>
   <h2 >
   <i class="glyphicon glyphicon-th-list"></i> 
        Menu Course
    </h2>
</div>		

<div class="container col-sm-6">
    <div class="row text-left">
        <h1><center>Seafood</h1>
    </div>
    <div class="row">
    <a href="orderadd1.php">
        <div class="image-block col-sm-4" style="background: url(img/a.jpg) no-repeat center top;background-size:cover;">
            <p> Sinigang Shrimp - Php 80.00 </p>
        </div></a>
        <a href="orderadd1.php">
        <div class="image-block col-sm-8" style="background: url(img/c.jpg) no-repeat center top;background-size:cover;">
            <p>Tinola (Classic filipino fish soup) - Php 70.00</p>
        </div></a>
        <a href="orderadd1.php">
        <div class="image-block col-sm-3" style="background: url(img/b.jpg) no-repeat center top;background-size:cover;">
            <p> Linarang Sinigang - Php 70.00 </p>
        </div></a>
        <a href="orderadd1.php">
        <div class="image-block col-sm-4" style="background: url(img/d.jpg) no-repeat center top;background-size:cover;">
            <p> Sinigang - Php 70.00 </p>
        </div></a>
        <a href="orderadd1.php">
        <div class="image-block col-sm-5" style="background: url(img/f.jpg) no-repeat center top;background-size:cover;">
            <p> Calamaris - Php 70.00</p>
        </div></a>
        <a href="orderadd1.php">
        <div class="image-block col-sm-8" style="background: url(img/g.jpg) no-repeat center top;background-size:cover;">
            <p>Camaron Rebosado - Php 80.00 </p>
        </div></a>
        <a href="orderadd1.php">
        <div class="image-block col-sm-4" style="background: url(img/h.jpg) no-repeat center top;background-size:cover;">
            <p> Gambas - Php 80.00 </p>            
        </div></a>
    </div>
</div>

<div class="container-fluid col-sm-6">
    <div class="row text-left">
        <h1><center>BBQ</h1>
    </div>
    <div class="row">
    <a href="orderadd1.php">
        <div class="image-block col-sm-4" style="background: url(img/c1.jpg) no-repeat center top;background-size:cover;">
            <p> Isaw - Php 5.00 </p>
        </div></a>
        <a href="orderadd1.php">
        <div class="image-block col-sm-5" style="background: url(img/c2.jpg) no-repeat center top;background-size:cover;">
            <p> Pork BBQ - Php 6.00 </p>
        </div></a>
        <div class="image-block col-sm-3" style="background: url(img/c3.jpg) no-repeat center top;background-size:cover;">
            <p> Belly - Php 15.00</p>
        </div>
        <a href="orderadd1.php">
        <div class="image-block col-sm-7" style="background: url(img/c4.jpg) no-repeat center top;background-size:cover;">
            <p> Liver - Php 15.00 </p>
        </div></a>
        <a href="orderadd1.php">
        <div class="image-block col-sm-5" style="background: url(img/c5.jpg) no-repeat center top;background-size:cover;">
            <p> Skinless - Php 15.00 </p>
        </div></a>
        <a href="orderadd1.php">
        <div class="image-block col-sm-4" style="background: url(img/c6.jpg) no-repeat center top;background-size:cover;">
            <p> Wings - Php 35.00 </p>
        </div></a>
        <a href="orderadd1.php">
        <div class="image-block col-sm-8" style="background: url(img/c7.jpg) no-repeat center top;background-size:cover;">
            <p> Paa - Php 45.00 </p>
        </div></a>

    </div>
    </div>
<div class="container-fluid col-sm-6">
    <div class="row text-left">
        <h1><center>Platters  </h1>
    </div>
    <div class="row">
        <a href="orderadd1.php">
        <div class="image-block col-sm-8" style="background: url(img/b1.jpg) no-repeat center top;background-size:cover;">
            <p> Bihon - Php 70.00 </p>
        </div></a>
        <a href="orderadd1.php">
        <div class="image-block col-sm-4" style="background: url(img/b2.jpg) no-repeat center top;background-size:cover;">
            <p> Special Pansit Canton- Php 70.00 </p>
        </div></a>
        <a href="orderadd1.php">
        <div class="image-block col-sm-5" style="background: url(img/b3.jpg) no-repeat center top;background-size:cover;">
            <p> Special Bam-i - Php 70.00</p>
        </div></a>
        <a href="orderadd1.php">
        <div class="image-block col-sm-7" style="background: url(img/b4.jpg) no-repeat center top;background-size:cover;">
            <p> Garlic Rice - Php 65.00 </p>
        </div></a>

    </div>
</div>


<div class="container-fluid col-sm-6">
    <div class="row text-left">
        <h1><center>Sizzling</h1>
    </div>
    <div class="row">
    <a href="orderadd1.php">
        <div class="image-block col-sm-4" style="background: url(img/1.jpeg) no-repeat center top;background-size:cover;">
            <p> Sizzling Pork Sisig - Php 90.00 </p>
        </div></a>
        <a href="orderadd1.php">
        <div class="image-block col-sm-8" style="background: url(img/2.jpg) no-repeat center top;background-size:cover;">
            <p> Sizzling Spicy Squid - Php 70.00</p>
        </div></a>
       
    </div>
</div>

 <br>
 <hr class="col-sm-9">
      <footer class="col-sm-9">
        <p>&copy; Copyright All Right Reserved 2017 | Grill House</p>
      </footer><br>
    </div>
    </div>
<style>
.image-block {
    border: 3px solid white ;
    background-color: black;
    padding: 0px;    
    margin: 0px;
    height:200px;
    text-align: center;
    vertical-align: bottom;
}
.image-block > p {
    width: 100%;
    height: 100%;
    font-weight: normal;
    font-size: 13px;
    padding-top: 100px;
    background-color: rgba(3,3,3,0.0);
    color: rgba(6,6,6,0.0);
}
.image-block:hover > p {
    background-color: rgba(3,3,3,0.5);    
    color: white;    
}
</style>
<!-- Responsive Image Tiles - END -->
    
    <script src="assets/jquery-1.11.3-jquery.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    
</body>
</html>
<?php ob_end_flush(); ?>