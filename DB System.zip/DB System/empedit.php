<?php
	ob_start();
	session_start();
	require_once 'dbconnect.php';
	
	// if session is not set this will redirect to login page
	if( !isset($_SESSION['user']) ) {
		header("Location: index.php");
		exit;
	}
	// select loggedin users detail
	$res=mysql_query("SELECT * FROM users WHERE userId=".$_SESSION['user']);
	$userRow=mysql_fetch_array($res);
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Employee List - Edit | Admin's Page</title>
<link rel="stylesheet" href="assets/css/bootstrap.min.css" type="text/css"  />
<link rel="stylesheet" href="style.css" type="text/css" />
</head>
<body>

	<nav class="navbar navbar-default navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="emplist.php">Admin's Page</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
            <li  class="active"><a href="emplist.php">Employee List</a></li>
            <li><a href="order.php">Manage Order <span class="badge" style="background-color: red;">5</span></a></li>
            <li><a href="service.php">Service Package</a></li>
           <li><a href="about.php">About</a></li>
          </ul>
          <ul class="nav navbar-nav navbar-right">
            <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="" data-toggle="dropdown">Messege</span><span class="badge" style="background-color: red;">3</span></a>
            <div class="dropdown-menu" aria-labelledby="dropdown01" style="width: 250px;">
              <h5><center>Message</h5>
              <p>&nbsp;Customer's say # 1: </p>
              <p>&nbsp;Customer's say # 2: </p>
              <p>&nbsp;Customer's say # 3: </p>
            </div>
          </li>
            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
			  <span class="glyphicon glyphicon-user"></span>&nbsp;Hi' <?php echo $userRow['userEmail']; ?>&nbsp;<span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="logout.php?logout"><span class="glyphicon glyphicon-log-out"></span>&nbsp;Sign Out</a></li>
              </ul>
            </li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav> 

	<div id="wrapper">

	<div class="container">
  <br>
    <?php
include_once 'dbconnect.php';
if(isset($_POST['btn-update']))
{
  $id = $_GET['edit_id'];
  $fname = $_POST['first_name'];
  $lname = $_POST['last_name'];
  $addr = $_POST['address'];
  $dates = $_POST['dates'];
  $stat = $_POST['status'];
  $pos = $_POST['position'];
  if($crud->update($id,$fname,$lname,$addr,$dates,$stat,$pos))
  {
    $msg = "<div class='alert alert-info'>
        <strong>Employee</strong> was updated successfully !
        </div>";
  }
  else
  {
    $msg = "<div class='alert alert-warning'>
        <strong>SORRY!</strong> ERROR while updating employee !
        </div>";
  }
}

if(isset($_GET['edit_id']))
{
  $id = $_GET['edit_id'];
  extract($crud->getID($id)); 
}

?>

<div class="clearfix"></div>

<div class="container">
<?php
if(isset($msg))
{
  echo $msg;
}
?>
</div>

<div class="clearfix"></div>
<div class="container">
    <div class="page-header">
      <h2>
      <i class="glyphicon glyphicon-edit"></i> 
      Employee List - Edit
      </h2>
    </div>
     <form method='post'>
 
    <table class='table table-bordered'>
 
        <tr>
            <td>First Name</td>
            <td><input type='text' name='first_name' class='form-control' value="<?php echo $first_name; ?>" required></td>
        </tr>
 
        <tr>
            <td>Last Name</td>
            <td><input type='text' name='last_name' class='form-control' value="<?php echo $last_name; ?>" required></td>
        </tr>
 
        <tr>
            <td>Address</td>
            <td><input type='text' name='address' class='form-control' value="<?php echo $address; ?>" required></td>
        </tr>
        <tr>
            <td>Date Hired</td>
            <td><input type='date' name='dates' class='form-control' value="<?php echo $dates; ?>" required></td>
        </tr>
        <tr>
            <td>Status</td>
            <!--<td><input type='text' name='status' class='form-control' value="<?php echo $status; ?>" required></td>-->
            <td><select name='status' class='form-control' value="<?php echo $status; ?>">
              <option>Active</option>
              <option>In-Active</option>
            </select></td>
        </tr>
    
    <tr>
            <td>Position</td>
           <!-- <td><input type='text' name='position' class='form-control' value="<?php echo $position; ?>" required></td>-->
            <td>
              <select name='position' class='form-control' value="<?php echo $position; ?>">
              <option>Waiter</option>
              <option>Cook's Chef</option>
              <option>Cashier</option>
              <option>Deliver Boy</option>
              </select>
            </td>
        </tr>
        <tr>
            <td colspan="2">
                <button type="submit" class="btn" name="btn-update">
          <span class="glyphicon glyphicon-edit"></span> Update this Employee
        </button>
                <a href="emplist.php" class="btn btn-large btn-success"><i class="glyphicon glyphicon-backward"></i> &nbsp; Back</a>
            </td>
        </tr>
 
    </table>
</form>
     
     
</div>
<br><br><br>
<hr>
    <footer>
        <p>&copy; Copyright All Right Reserved 2017 | Admin's Page</p>
      </footer><br>
    

    </div>
    
    </div>
    
    <script src="assets/jquery-1.11.3-jquery.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    
</body>
</html>
<?php ob_end_flush(); ?>