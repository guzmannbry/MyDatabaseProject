<?php
	ob_start();
	session_start();
	require_once 'dbconnect.php';
	
	// if session is not set this will redirect to login page
	if( !isset($_SESSION['user']) ) {
		header("Location: index.php");
		exit;
	}
	// select loggedin users detail
	$res=mysql_query("SELECT * FROM users WHERE userId=".$_SESSION['user']);
	$userRow=mysql_fetch_array($res);
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Service Package | Admin's Page</title>
<link rel="stylesheet" href="assets/css/bootstrap.min.css" type="text/css"  />
<link rel="stylesheet" href="style.css" type="text/css" />
</head>
<body>

	<nav class="navbar navbar-default navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="emplist.php">Admin's Page</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
            <li><a href="emplist.php">Employee List</a></li>
            <li><a href="order.php">Manage Order <span class="badge" style="background-color: red;">5</span></a></li>
            <li class="active"><a href="service.php">Service Package</a></li>
            <li><a href="about.php">About</a></li>
            
            </ul>
          <ul class="nav navbar-nav navbar-right">
             <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="" data-toggle="dropdown">Message</span><span class="badge" style="background-color: red;">3</span></a>
            <div class="dropdown-menu" aria-labelledby="dropdown01" style="width: 250px;">
              <h5><center>Message</h5>
                <p><center>2 Message From Customer 1 </p>
              <p><center>1 Message From Customer 2 </p>
              <p><center>2 Message From Customer 3 </p>
            </div>
          </li>
            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
			  <span class="glyphicon glyphicon-user"></span>&nbsp;Hi' <?php echo $userRow['userEmail']; ?>&nbsp;<span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="logout.php?logout"><span class="glyphicon glyphicon-log-out"></span>&nbsp;Sign Out</a></li>
              </ul>
            </li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav> 

	<div id="wrapper">

	<div class="container">
<div class="clearfix"></div>

<div class="container">
<br>
  <div class="page-header">
    <h2>
      <i class="glyphicon glyphicon-align-left"></i> 
      Service Package
      <a href="serviceadd.php" style="color: black; float:right;"><i class="glyphicon glyphicon-plus" style="color: black;"> </i> Add Service Package</a>  
    </h2>
  </div>
</div>

<div class="clearfix"></div><br />

<div class="container">
   <table class='table table-bordered table-responsive'>
     <tr>
     <th>#</th>
     <th>Price</th>
     <th>Descriptions</th>
     <th colspan="2" align="center">Actions</th>
     </tr>
     <?php
    $query = "SELECT * FROM tbl_service";       
    $records_per_page=10;
    $newquery = $service->paging($query,$records_per_page);
    $service->dataview($newquery);
   ?>
    <tr>
        <td colspan="5" align="center">
      <div class="pagination-wrap">
            <?php $service->paginglink($query,$records_per_page); ?>
          </div>
        </td>
    </tr>
 
</table>
</div>

      <hr>
      <footer>
        <p>&copy; Copyright All Right Reserved 2017 | Admin's Page</p>
      </footer><br>
    </div>
    
    </div>
    
    <script src="assets/jquery-1.11.3-jquery.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    
</body>
</html>
<?php ob_end_flush(); ?>