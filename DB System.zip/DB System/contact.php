<?php
	ob_start();
	session_start();
	require_once 'dbconnect.php';
	
	// if session is not set this will redirect to login page
	if( !isset($_SESSION['user']) ) {
		header("Location: index.php");
		exit;
	}
	// select loggedin users detail
	$res=mysql_query("SELECT * FROM users WHERE userId=".$_SESSION['user']);
	$userRow=mysql_fetch_array($res);
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Home | Admin's Page</title>
<link rel="stylesheet" href="assets/css/bootstrap.min.css" type="text/css"  />
<link rel="stylesheet" href="style.css" type="text/css" />
</head>
<body>

	<nav class="navbar navbar-inverse navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="emplist.php">Admin's Page</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
            <li><a href="emplist.php">Employee List</a></li>
            <li><a href="order.php">Manage Order</a></li>
          <li><a href="about.php">About</a></li>
            <li class="active"><a href="contact.php">Contact</a></li>
          </ul>
          <ul class="nav navbar-nav navbar-right">
            
            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
			  <span class="glyphicon glyphicon-user"></span>&nbsp;Hi' <?php echo $userRow['userEmail']; ?>&nbsp;<span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="logout.php?logout"><span class="glyphicon glyphicon-log-out"></span>&nbsp;Sign Out</a></li>
              </ul>
            </li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav> 


	<div class="container">
	<br><br>
	<div class="page-header" >
	   <h2 >
	   <i class="glyphicon glyphicon-phone-alt"></i> 
	        Contact Us
	    </h2>
	</div>
    <center>
 		<div style="width: 60%;">
         <h2 >
	   <i class="glyphicon glyphicon-phone-alt"></i> 
	    	 <br>    Contact Us
	    </h2>
              <hr style="background-color:black; width: 250px; ">
               
               <input type="name" id="inputName" class="form-control" placeholder="Your name" required autofocus>
               <input type="email" id="inputEmail" class="form-control" placeholder="Your email" required autofocus>
               <input type="subject" id="inputSubject" class="form-control" placeholder="Subject" required autofocus>
               <label >
                 <textarea class="form-control" rows="5" cols="120"  placeholder="Messege here...."></textarea>
               </label>
               <button class="btn btn-lg btn-primary btn-block" type="submit">Send Messege</button>
              </div>
      <hr>
     <h2 >
	   <i class="glyphicon glyphicon-map-marker"></i> 
	    <br>    My Office
	    </h2>
		    <h4>Address : Don Mariano Cui St, Cebu City, Cebu</h4>
		    <h4>Phone: (032) 254 1252</h4>
		    <h4>Website: https://www.facebook.com/NANAYSGRILL</h4>
		    <h4>Category: Catering and BBQ</h4>
    	<img src="map-ps.jpg" style="width:100%;height:100%;">
      <!--<div id="googleMap" style="width:100%;height:500px;"></div>

			<script>
			function myMap() {
			var mapProp= {
			    center:new google.maps.LatLng(10.3125182,123.8910636),
			    zoom:30,
			};
			var map=new google.maps.Map(document.getElementById("googleMap"),mapProp);
			}
			</script>

			<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAYcjzjgzkEwn0jc1xLjXlNpAIGS0AHrjg&callback=myMap"></script>
			<!--
			To use this code on your website, remove the API key:
			<script src="https://maps.googleapis.com/maps/api/js?callback=myMap"></script>
			-->
			    <br>
 <hr>
 <footer style="float: left">
        <p >&copy; Copyright All Right Reserved 2017 | Admin's Page</p>
      </footer><br>
	
    </div>
    </div>
    
    
    <script src="assets/jquery-1.11.3-jquery.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    
</body>
</html>
<?php ob_end_flush(); ?>