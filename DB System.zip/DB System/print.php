<?php
echo "<table border='1' id= results>
<tr>
<th>FILEID</th>
<th>Firstname</th>
<th>Lastname</th>
<th>Issue Date</th>
<th>Interest Rate</th>
<th>Terms</th>
<th>Balance Outstanding</th>
<th>Balance Outstanding</th>
<th>New Loan</th>
<th>Principal Repayment for $l_month</th>
<th>Principal Repaid</th>
<th>Balance Outstanding</th>
<th>Interest Payment for $l_month </th>
<th>INTEREST ACCUMULATED DURING FINNANCIAL YEAR</th>
</tr>";

while($row = mysql_fetch_array($result))
  {


  echo "<tr>"; 

    echo "<td>" . $row['app_file_id'] . "</td>";
    echo"<td>". $row['app_fname']."</td>";
    echo"<td>". $row['app_lname']."</td>";
    echo"<td>". $row['commit_date'] ."</td>";
    echo"<td>". $row['computer_interest'] ."</td>";
    echo"<td>". $row['loan_life'] ."</td>";
    echo"<td>". $row['avg(app_ln_amnt)'] ."</td>";
    echo"<td>". $row['Balance Outstanding'] ."</td>";
    echo"<td>". $row['New Loan'] ."</td>";
    echo"<td>". $row['SUM(r.receipt_on_principal)'] ."</td>";
    echo"<td>". $row['Principal Repaid'] ."</td>";
    echo"<td>". $row['avg(app_amnt_owed)'] ."</td>";    
    echo"<td>". $row['SUM(r.receipt_on_interest)'] ."</td>";
    echo"<td>". $row['Interest Accumilated'] ."</td>";
  echo "</tr>";
  }
echo "</table>";
?>